//
//  WoL_ManuApp.swift
//  WoL Manu
//
//  Created by Manuel Alonso Rodriguez on 28/9/25.
//

import SwiftUI

@main
struct WoL_ManuApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
